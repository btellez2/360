package com.example.myapplication;

import android.Manifest;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EventsActivity extends AppCompatActivity {

    // Background thread for database operations.
    private final ExecutorService executor =
            Executors.newSingleThreadExecutor();

    // Current user and selected event.
    private long userId;
    private long editingId = -1;

    // Event input fields.
    private EditText name;
    private EditText date;
    private EditText time;
    private EditText location;
    private EditText phone;

    // Event list and buttons.
    private LinearLayout rows;
    private Button save;
    private Button cancel;
    private ScrollView scroll;
    private TextView formHeading;

    // Stores events retrieved from SQLite.
    private ArrayList<DatabaseHelper.Event> currentEvents =
            new ArrayList<>();

    // Date and time formats.
    private final SimpleDateFormat dateFormat =
            new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    private final SimpleDateFormat timeFormat =
            new SimpleDateFormat("hh:mm a", Locale.US);

    private final SimpleDateFormat militaryTimeFormat =
            new SimpleDateFormat("HH:mm", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Retrieve the logged-in user's ID.
        userId = getIntent().getLongExtra("user_id", -1);

        if (userId < 0) {
            finish();
            return;
        }

        setContentView(R.layout.activity_events);

        // Connect Java variables to XML components.
        name = findViewById(R.id.editEventName);
        date = findViewById(R.id.editEventDate);
        time = findViewById(R.id.editEventTime);
        location = findViewById(R.id.editEventLocation);
        phone = findViewById(R.id.editPhone);

        rows = findViewById(R.id.eventRows);
        save = findViewById(R.id.buttonAddEvent);
        cancel = findViewById(R.id.buttonCancelEdit);

        scroll = findViewById(R.id.eventsScroll);
        formHeading = findViewById(R.id.formHeading);

        // Configure date and time formats.
        dateFormat.setLenient(false);
        timeFormat.setLenient(false);
        militaryTimeFormat.setLenient(false);

        // Prevent manual typing into date and time fields.
        date.setFocusable(false);
        time.setFocusable(false);

        // Open calendar when the date field is selected.
        date.setOnClickListener(v -> showDatePicker());

        // Open 12-hour time picker with AM/PM.
        time.setOnClickListener(v -> showTimePicker());

        // Save or update an event.
        save.setOnClickListener(v -> saveEvent());

        // Cancel editing.
        cancel.setOnClickListener(v -> clearForm());

        // Handle SMS notification permission.
        findViewById(R.id.buttonSMS).setOnClickListener(v -> {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        101
                );

            } else {
                sendTestReminder();
            }
        });

        // Load saved events from SQLite.
        refresh();
    }

    // ----------------------------------------------------
    // DATE PICKER
    // ----------------------------------------------------

    private void showDatePicker() {

        Calendar calendar = Calendar.getInstance();

        // Reopen the calendar at the currently selected date.
        String currentDate = date.getText().toString().trim();

        if (!currentDate.isEmpty()) {
            try {
                Date selectedDate = dateFormat.parse(currentDate);

                if (selectedDate != null) {
                    calendar.setTime(selectedDate);
                }

            } catch (ParseException ignored) {
                // Use today's date if the saved date is invalid.
            }
        }

        DatePickerDialog datePickerDialog =
                new DatePickerDialog(
                        this,
                        (view, year, month, day) -> {

                            String formattedDate = String.format(
                                    Locale.US,
                                    "%04d-%02d-%02d",
                                    year,
                                    month + 1,
                                    day
                            );

                            date.setText(formattedDate);
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                );

        datePickerDialog.show();
    }

    // ----------------------------------------------------
    // TIME PICKER - 12 HOUR FORMAT
    // ----------------------------------------------------

    private void showTimePicker() {

        Calendar calendar = Calendar.getInstance();

        String currentTime = time.getText().toString().trim();

        // Use the saved event time when editing.
        if (!currentTime.isEmpty()) {

            Date selectedTime = parseTime(currentTime);

            if (selectedTime != null) {
                calendar.setTime(selectedTime);
            }
        }

        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog =
                new TimePickerDialog(
                        this,
                        (view, selectedHour, selectedMinute) -> {

                            Calendar selectedTime =
                                    Calendar.getInstance();

                            selectedTime.set(
                                    Calendar.HOUR_OF_DAY,
                                    selectedHour
                            );

                            selectedTime.set(
                                    Calendar.MINUTE,
                                    selectedMinute
                            );

                            // Display time using AM/PM.
                            String formattedTime =
                                    timeFormat.format(
                                            selectedTime.getTime()
                                    );

                            time.setText(formattedTime);
                        },
                        hour,
                        minute,
                        false // false = 12-hour AM/PM format
                );

        timePickerDialog.show();
    }

    // ----------------------------------------------------
    // TIME FORMAT CONVERSION
    // ----------------------------------------------------

    private Date parseTime(String value) {

        try {
            return timeFormat.parse(value);

        } catch (ParseException ignored) {
            // Try military time for older saved events.
        }

        try {
            return militaryTimeFormat.parse(value);

        } catch (ParseException ignored) {
            return null;
        }
    }

    private String formatDisplayTime(String value) {

        Date parsedTime = parseTime(value);

        if (parsedTime == null) {
            return value;
        }

        return timeFormat.format(parsedTime);
    }

    // ----------------------------------------------------
    // SAVE OR UPDATE EVENT
    // ----------------------------------------------------

    private void saveEvent() {

        String eventName =
                name.getText().toString().trim();

        String eventDate =
                date.getText().toString().trim();

        String eventTime =
                time.getText().toString().trim();

        String eventLocation =
                location.getText().toString().trim();

        // Validate required fields.
        if (eventName.isEmpty()
                || eventDate.isEmpty()
                || eventTime.isEmpty()) {

            Toast.makeText(
                    this,
                    R.string.error_enter_event_details,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Check that the selected time is valid.
        if (parseTime(eventTime) == null) {

            Toast.makeText(
                    this,
                    R.string.error_valid_time,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        long eventId = editingId;

        save.setEnabled(false);

        executor.execute(() -> {

            try (DatabaseHelper database =
                        new DatabaseHelper(getApplicationContext())) {

                database.saveEvent(
                        eventId,
                        userId,
                        eventName,
                        eventDate,
                        eventTime,
                        eventLocation
                );

                runOnUiThread(() -> {

                    clearForm();

                    save.setEnabled(true);

                    Toast.makeText(
                            this,
                            R.string.event_saved_success,
                            Toast.LENGTH_SHORT
                    ).show();

                    refresh();
                });

            } catch (Exception error) {

                runOnUiThread(() -> {

                    save.setEnabled(true);

                    Toast.makeText(
                            this,
                            R.string.error_save_event,
                            Toast.LENGTH_LONG
                    ).show();
                });
            }
        });
    }

    // ----------------------------------------------------
    // LOAD EVENTS FROM SQLITE
    // ----------------------------------------------------

    private void refresh() {

        executor.execute(() -> {

            try (DatabaseHelper database =
                        new DatabaseHelper(getApplicationContext())) {

                ArrayList<DatabaseHelper.Event> events =
                        database.events(userId);

                runOnUiThread(() -> {

                    currentEvents = events;

                    rows.removeAllViews();

                    if (events.isEmpty()) {

                        TextView emptyMessage =
                                new TextView(this);

                        emptyMessage.setText(R.string.no_events_message);

                        rows.addView(emptyMessage);
                    }

                    for (DatabaseHelper.Event event : events) {

                        createEventRow(event);
                    }
                });

            } catch (Exception error) {

                runOnUiThread(() ->

                        Toast.makeText(
                                this,
                                R.string.error_load_events,
                                Toast.LENGTH_LONG
                        ).show()
                );
            }
        });
    }

    // ----------------------------------------------------
    // DISPLAY EVENT ROW
    // ----------------------------------------------------

    private void createEventRow(DatabaseHelper.Event event) {

        LinearLayout row = new LinearLayout(this);

        row.setOrientation(LinearLayout.VERTICAL);

        row.setPadding(8, 12, 8, 12);

        TextView eventText = new TextView(this);

        String displayTime =
                formatDisplayTime(event.time);

        String locationText = (event.location == null || event.location.isEmpty())
                ? ""
                : event.location;

        String formattedEventText = getString(
                R.string.event_row_format,
                event.name,
                event.date,
                displayTime,
                locationText.isEmpty() ? "" : "\n" + locationText
        );

        eventText.setText(formattedEventText);

        row.addView(eventText);

        LinearLayout actions =
                new LinearLayout(this);

        actions.setOrientation(
                LinearLayout.HORIZONTAL
        );

        // Edit button.
        Button editButton = createEditButton(event);
        actions.addView(editButton);

        // Delete button.
        Button deleteButton = createDeleteButton(event);
        actions.addView(deleteButton);

        row.addView(actions);

        rows.addView(row);
    }

    private Button createEditButton(DatabaseHelper.Event event) {
        Button editButton = new Button(this);

        editButton.setText(R.string.button_edit);

        editButton.setOnClickListener(v -> {

            editingId = event.id;

            name.setText(event.name);

            date.setText(event.date);

            time.setText(
                    formatDisplayTime(event.time)
            );

            location.setText(
                    event.location == null
                            ? ""
                            : event.location
            );

            save.setText(R.string.button_update_event);

            formHeading.setText(R.string.heading_edit_event);

            cancel.setVisibility(View.VISIBLE);

            scroll.smoothScrollTo(0, 0);
        });
        return editButton;
    }

    private Button createDeleteButton(DatabaseHelper.Event event) {
        Button deleteButton = new Button(this);

        deleteButton.setText(R.string.button_delete);

        deleteButton.setOnClickListener(v ->

                new AlertDialog.Builder(this)

                        .setTitle(R.string.dialog_title_delete_event)

                        .setMessage(getString(
                                R.string.delete_event_confirm_message,
                                event.name
                        ))

                        .setNegativeButton(
                                R.string.button_cancel,
                                null
                        )

                        .setPositiveButton(
                                R.string.button_delete,
                                (dialog, which) ->
                                        deleteEvent(event)
                        )

                        .show()
        );
        return deleteButton;
    }

    // ----------------------------------------------------
    // DELETE EVENT
    // ----------------------------------------------------

    private void deleteEvent(DatabaseHelper.Event event) {

        executor.execute(() -> {

            try (DatabaseHelper database =
                        new DatabaseHelper(getApplicationContext())) {

                database.deleteEvent(
                        event.id,
                        userId
                );

                runOnUiThread(() -> {

                    if (editingId == event.id) {
                        clearForm();
                    }

                    Toast.makeText(
                            this,
                            R.string.event_deleted_success,
                            Toast.LENGTH_SHORT
                    ).show();

                    refresh();
                });

            } catch (Exception error) {

                runOnUiThread(() ->

                        Toast.makeText(
                                this,
                                R.string.error_delete_event,
                                Toast.LENGTH_LONG
                        ).show()
                );
            }
        });
    }

    // ----------------------------------------------------
    // CLEAR EVENT FORM
    // ----------------------------------------------------

    private void clearForm() {

        editingId = -1;

        name.setText("");

        date.setText("");

        time.setText("");

        location.setText("");

        save.setText(R.string.button_save_event);

        formHeading.setText(R.string.heading_add_new_event);

        cancel.setVisibility(View.GONE);
    }

    // ----------------------------------------------------
    // SMS EVENT REMINDER
    // ----------------------------------------------------

    private void sendTestReminder() {

        String phoneNumber =
                phone.getText().toString().trim();

        // Validate phone number.
        if (!phoneNumber.matches("\\+?[0-9]{7,15}")) {

            Toast.makeText(
                    this,
                    R.string.error_valid_phone,
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        DatabaseHelper.Event upcomingEvent = null;

        Date now = new Date();

        Date earliestDate = null;

        // Find the nearest upcoming event.
        for (DatabaseHelper.Event event : currentEvents) {

            try {

                Date eventDate =
                        dateFormat.parse(event.date);

                Date eventTime =
                        parseTime(event.time);

                if (eventDate == null || eventTime == null) {
                    continue;
                }

                Calendar eventCalendar =
                        Calendar.getInstance();

                eventCalendar.setTime(eventDate);

                Calendar timeCalendar =
                        Calendar.getInstance();

                timeCalendar.setTime(eventTime);

                eventCalendar.set(
                        Calendar.HOUR_OF_DAY,
                        timeCalendar.get(
                                Calendar.HOUR_OF_DAY
                        )
                );

                eventCalendar.set(
                        Calendar.MINUTE,
                        timeCalendar.get(
                                Calendar.MINUTE
                        )
                );

                eventCalendar.set(
                        Calendar.SECOND,
                        0
                );

                eventCalendar.set(
                        Calendar.MILLISECOND,
                        0
                );

                Date fullEventDate =
                        eventCalendar.getTime();

                if (!fullEventDate.before(now)) {

                    if (earliestDate == null
                            || fullEventDate.before(earliestDate)) {

                        earliestDate = fullEventDate;

                        upcomingEvent = event;
                    }
                }

            } catch (ParseException ignored) {
                // Skip invalid event dates.
            }
        }

        if (upcomingEvent == null) {

            Toast.makeText(
                    this,
                    R.string.error_no_upcoming_event,
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        String message = getString(
                R.string.event_reminder_format,
                upcomingEvent.name,
                upcomingEvent.date,
                formatDisplayTime(upcomingEvent.time)
        );

        try {

            SmsManager smsManager = getSystemService(SmsManager.class);

            if (smsManager != null) {
                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        message,
                        null,
                        null
                );

                Toast.makeText(
                        this,
                        R.string.sms_reminder_requested,
                        Toast.LENGTH_SHORT
                ).show();
            } else {
                Toast.makeText(
                        this,
                        R.string.sms_unavailable,
                        Toast.LENGTH_LONG
                ).show();
            }

        } catch (Exception error) {

            Toast.makeText(
                    this,
                    R.string.sms_unavailable,
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // ----------------------------------------------------
    // SMS PERMISSION RESULT
    // ----------------------------------------------------

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == 101) {

            if (grantResults.length > 0
                    && grantResults[0]
                    == PackageManager.PERMISSION_GRANTED) {

                sendTestReminder();

            } else {

                Toast.makeText(
                        this,
                        R.string.sms_disabled_message,
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    // ----------------------------------------------------
    // CLEAN UP BACKGROUND THREAD
    // ----------------------------------------------------

    @Override
    protected void onDestroy() {

        executor.shutdown();

        super.onDestroy();
    }
}