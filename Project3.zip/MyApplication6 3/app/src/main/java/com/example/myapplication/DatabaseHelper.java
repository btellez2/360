package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Locale;

/** Persistent local storage for user accounts and events. */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "event_tracker.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, salt TEXT NOT NULL, password_hash TEXT NOT NULL)");
        db.execSQL("CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, name TEXT NOT NULL, event_date TEXT NOT NULL, event_time TEXT NOT NULL, location TEXT, FOREIGN KEY(user_id) REFERENCES users(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        /* Migrations go here for future versions. */
    }

    private static String hex(byte[] bytes) {
        StringBuilder b = new StringBuilder();
        for (byte x : bytes) {
            b.append(String.format(Locale.US, "%02x", x & 0xFF));
        }
        return b.toString();
    }

    private static String hash(String salt, String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return hex(md.digest((salt + password).getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean register(String username, String password) {
        byte[] bytes = new byte[16];
        new SecureRandom().nextBytes(bytes);
        String salt = hex(bytes);
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("salt", salt);
        values.put("password_hash", hash(salt, password));
        return getWritableDatabase().insertWithOnConflict("users", null, values, SQLiteDatabase.CONFLICT_IGNORE) != -1;
    }

    public long authenticate(String username, String password) {
        try (Cursor c = getReadableDatabase().query("users", new String[]{"id", "salt", "password_hash"}, "username=?", new String[]{username}, null, null, null)) {
            if (c.moveToFirst() && MessageDigest.isEqual(hash(c.getString(1), password).getBytes(StandardCharsets.UTF_8), c.getString(2).getBytes(StandardCharsets.UTF_8))) {
                return c.getLong(0);
            }
        }
        return -1;
    }

    public static class Event {
        public final long id;
        public final String name;
        public final String date;
        public final String time;
        public final String location;

        Event(long id, String name, String date, String time, String location) {
            this.id = id;
            this.name = name;
            this.date = date;
            this.time = time;
            this.location = location;
        }
    }

    public ArrayList<Event> events(long userId) {
        ArrayList<Event> result = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query("events", new String[]{"id", "name", "event_date", "event_time", "location"}, "user_id=?", new String[]{String.valueOf(userId)}, null, null, "event_date, event_time")) {
            while (c.moveToNext()) {
                result.add(new Event(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4)));
            }
        }
        return result;
    }

    public void saveEvent(long id, long userId, String name, String date, String time, String location) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("event_date", date);
        v.put("event_time", time);
        v.put("location", location);
        if (id < 0) {
            v.put("user_id", userId);
            getWritableDatabase().insertOrThrow("events", null, v);
        } else {
            getWritableDatabase().update("events", v, "id=? AND user_id=?", new String[]{String.valueOf(id), String.valueOf(userId)});
        }
    }

    public void deleteEvent(long id, long userId) {
        getWritableDatabase().delete("events", "id=? AND user_id=?", new String[]{String.valueOf(id), String.valueOf(userId)});
    }
}
