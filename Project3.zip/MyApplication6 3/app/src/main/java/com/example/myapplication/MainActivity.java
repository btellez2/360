package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText username;
    private EditText password;
    private Button login;
    private Button register;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        username = findViewById(R.id.editUsername);
        password = findViewById(R.id.editPassword);
        login = findViewById(R.id.buttonLogin);
        register = findViewById(R.id.buttonCreateAccount);

        TextWatcher watcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                boolean ready = !username.getText().toString().trim().isEmpty() && !password.getText().toString().isEmpty();
                login.setEnabled(ready);
                register.setEnabled(ready);
            }
            public void afterTextChanged(Editable s) {}
        };

        username.addTextChangedListener(watcher);
        password.addTextChangedListener(watcher);
        login.setEnabled(false);
        register.setEnabled(false);
        login.setOnClickListener(v -> submit(false));
        register.setOnClickListener(v -> submit(true));
    }

    private void submit(boolean create) {
        String u = username.getText().toString().trim();
        String p = password.getText().toString();

        if (u.isEmpty() || p.isEmpty() || (create && p.length() < 8)) {
            Toast.makeText(this, R.string.error_credentials_length, Toast.LENGTH_LONG).show();
            return;
        }

        login.setEnabled(false);
        register.setEnabled(false);

        executor.execute(() -> {
            try (DatabaseHelper db = new DatabaseHelper(getApplicationContext())) {
                boolean created = !create || db.register(u, p);
                long userId = created ? db.authenticate(u, p) : -1;

                runOnUiThread(() -> {
                    login.setEnabled(true);
                    register.setEnabled(true);
                    if (userId >= 0) {
                        Intent intent = new Intent(this, EventsActivity.class);
                        intent.putExtra("user_id", userId);
                        startActivity(intent);
                    } else {
                        Toast.makeText(this, create ? R.string.error_username_exists : R.string.error_invalid_credentials, Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    login.setEnabled(true);
                    register.setEnabled(true);
                    Toast.makeText(this, R.string.error_db_access, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    @Override
    protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
